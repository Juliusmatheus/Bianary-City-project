<?php
include('model.inc.php');
include('controller.inc.php');
include('view.inc.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <?php
    $cssFile = "css/style.css";
    echo "<link rel='stylesheet' href='" . $cssFile . "'>";
    ?>
    <title>Display</title>



    <script>
        function openPage(evt, cityName) 
        {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) 
            {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) 
            {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(cityName).style.display = "block";
            evt.currentTarget.className += " active";
        }
    </script>

</head>

<body>
    <div class="tab">
        <button class="tablinks" onclick="openPage(event, 'Contact')">Form for Contact</button>
        <button class="tablinks" onclick="openPage(event, 'View')">View the contact</button>
        <button class="tablinks" onclick="openPage(event, 'Link')">Link Contact form To Client Form</button>
    </div>

    <div id="Contact" class="tabcontent">
        <h3>Contact </h3>
        <form action="controller.inc.php" method="POST">
            <input type="email" name="email" id="" placeholder="Email Addres" required>
            <input type="submit" name="save1" value="save">
        </form>
    </div>


    <div id="Link" class="tabcontent">
        <h3>Link Contact form To Client Form</h3>
        <form action="controller.inc.php" method="POST">
            <input type="email" name="email" id="" placeholder="email" required>
            <input type="text" name="code" id="" placeholder="Contact_code" required>
            <input type="submit" name="submit1" value="submit">
        </form>
    </div>


    <div id="View" class="tabcontent">
        <h3>View of Contact And Linked Client</h3>
        <?php
        $data = new View();
        $data->showAllContact();
        ?>

    </div>
    <div id="Views" class="tabcontent">
        <h3>View of Contact And Linked Client</h3>
        <?php
        $data = new View();
        $data->showAllLinkedContact();
        ?>
    </div>

    <?php
    $fullUrl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    if (strpos($fullUrl, "status=added_contact")) 
    {
    ?>
        <script>
            swal({
                title: "Successfully added contact",
                icon: "success",
                button: "Ok",
            });
        </script>
    <?php
    } elseif (strpos($fullUrl, "status=contact_exists"))
     {
    ?>
        <script>
            swal({
                title: "Email already exists!",
                icon: "error",
                button: "Ok",
            });
        </script>
    <?php



    }

    if (strpos($fullUrl, "status=client_contact_join")) 
    {
    ?>
        <script>
            swal({
                title: "Successfully linked client to contact",
                icon: "success",
                button: "Ok",
            });
        </script>
    <?php
    } elseif (strpos($fullUrl, "status=error_joining")) 
    {
    ?>
        <script>
            swal({
                title: "Error occured",
                icon: "error",
                button: "Ok",
            });
        </script>
    <?php
    }


    if (strpos($fullUrl, "status=unlink_client_contact")) 
    {
    ?>
        <script>
            swal({
                title: "Successfully unlinked client from contact",
                icon: "success",
                button: "Ok",
            });
        </script>
    <?php
    } elseif (strpos($fullUrl, "status=error_unlinkin")) 
    {
    ?>
        <script>
            swal({
                title: "Error occured",
                icon: "error",
                button: "Ok",
            });
        </script>
    <?php
    }
    ?>

    <!-- <div class="clearfix"></div> -->

  
</body>

</html>