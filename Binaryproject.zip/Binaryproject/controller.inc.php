<?php

require_once('model.inc.php');

class Controller extends Model
{
    #getting user input and sending it to the controller
    public function getDataFromClient($firstName, $lastfirstName)
    {
        //user inputs
        $firstName = trim($firstName);
        $firstName = stripcslashes($firstName);
        $firstName = htmlspecialchars($firstName);
        $lastfirstName = trim($lastfirstName);
        $lastfirstName = stripcslashes($lastfirstName);
        $lastfirstName = htmlspecialchars($lastfirstName);

        $temp = $firstName;

        #creating 3 random characters
        if (strlen($temp) < 3)
         {
            $alphabetChars = 'abcdrfghiklmnopqlstuvxyz';

            $input_length = strlen($alphabetChars);
            $tempName = '';

            for ($i = 0; $i < 5; $i++) 
            {
                $tempName .= $alphabetChars[rand(0, $input_length - 1)];
            }

            $temp = $temp . $tempName;
        }

        //getting 3 character from userfirstName
        $code = substr($temp, 0, 3);
        $client_code = strtoupper($code);

        //send the data to the model
        $obj = new Controller();
        $obj->addClientToDataBase($firstName, $lastfirstName, $client_code);
    }

    #getting user input and sending it to the controller
    public function getDataFromContact($email)
    {
        //user inputs
        $email = trim($email);
        $email = stripcslashes($email);
        $email = htmlspecialchars($email);



        //send the data to the model
        $obj = new Controller();
        $obj->addContactToDataBase($email);
    }

    public function getLinkData($email, $code)
    {
        $obj = new Controller();
        $obj->addLink($email, $code);
    }
    public function unlink_Client_Contact($id)
    {
        $obj = new Controller();
        $obj->unlink($id);
    }
}

$control = new Controller();


#getting data from the user
if (isset($_POST['save'])) 
{
    $firstName = $_POST['fname'];
    $lastfirstName = $_POST['lname'];

    $control->getDataFromClient($firstName, $lastfirstName);
}
#getting data from the userTo link client with contact
if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $code = $_POST['code'];

    $control->getLinkData($email, $code);
}

#getting data from the user to add contact to database
if (isset($_POST['save1'])) 
{
    $email = $_POST['email'];


    $control->getDataFromContact($email);
}

#getting data from the userLink
if (isset($_POST['submit1'])) 
{
    $email = $_POST['email'];
    $code = $_POST['code'];

    $control->getLinkData($email, $code);
}

#this part of the code helps to unlink contact/client from contact/client

if (isset($_GET['client_id'])) 
{
    $id = $_GET['client_id'];

    // sql to delete a record
    $control->unlink_Client_Contact($id);
}
