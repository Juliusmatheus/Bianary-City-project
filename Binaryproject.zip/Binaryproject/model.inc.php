
<?php

require_once('Datbase.inc.php');

class Model extends Database
{
    //THIS IS THE FUNCTION TO INSERT THE CLIENT TO THE DATABASE
    protected function addClientToDataBase($fname, $lname, $client_code)
    {

        $conn = $this->connect();

        //THIS PART IS WHERE THE CLIENT CODE IS BEING GENERATED
        $select_code = "SELECT * FROM client_code WHERE contact_id = 1";
        $number_result = $this->connect()->query($select_code);

        $numeric_digits = 0;
        while ($row = $number_result->fetch_assoc())
         {
            $numeric_digits = $row['number'];
        }


        $numeric_digits++;

        //THIS PART IS WHERE THE CLIENT CODE IS BEING UPDATED AND SAVED TO THE DATABASE
        $number_update = "UPDATE client_code SET number=$numeric_digits where contact_id = 1";
        $this->connect()->query($number_update);

        //THIS PART IS WHERE WE ARE JOINING THE CLIENT CODE(ALPHABET) AND THE CLIENT CODE NUMERIC
        $client_code = $client_code . $numeric_digits;

        //THIS PART OF THE CODE CHECKS IF THE USER EXISTS ALREADY BEFORE WE INSERT TO THE DATABASE 
        $query_check = "SELECT * FROM client where client_code = $client_code";
        $result = mysqli_prepare($conn, $query_check);


        //THIS PART IS WHERE WE ARE SAVING THE USER TO THE DATABASE

        $inser_client = "INSERT INTO client(first_name,last_name,client_code) Values(?,?,?)";



        if (empty($result)) {
            $prepare_insert_client = mysqli_prepare($conn, $inser_client);
            mysqli_stmt_bind_param($prepare_insert_client, "sss", $fname, $lname, $client_code);
            mysqli_stmt_execute($prepare_insert_client);

            // $statement->execute();
            // $statement->close();

            Header("Location: client.php?status=added_client");
            exit();
        } else {
            Header("Location: client.php?status=client_exists");
            exit();
        }
    }

    //THIS IS THE FUNCTION TO INSERT THE CLIENT TO THE DATABASE
    protected function addContactToDataBase($email)
    {

        $conn = $this->connect();



        //THIS PART IS WHERE WE ARE SAVING THE USER TO THE DATABASE

        $inser_client = "INSERT INTO contact(email) Values(?)";



        if (empty($result)) {
            $prepare_insert_client = mysqli_prepare($conn, $inser_client);
            mysqli_stmt_bind_param($prepare_insert_client, "s", $email);
            mysqli_stmt_execute($prepare_insert_client);

            // $statement->execute();
            // $statement->close();

            Header("Location: contact.php?status=added_contact");
            exit();
        } else {
            Header("Location: contact.php?status=contact_exists");
            exit();
        }
    }
    protected function addLink($email, $code)
    {
        $conn = $this->connect();

        //HERE WE ARE SELECTING THE CLIENT ID AND STORE IT IN A VARIABLE
        $select_temp_client_id = "SELECT client.client_id from client
        where client.client_code= ?";

        $temp_client_id = mysqli_prepare($conn, $select_temp_client_id);
        mysqli_stmt_bind_param($temp_client_id, "s", $code);
        mysqli_stmt_execute($temp_client_id);




        $client_id = 0;
        mysqli_stmt_bind_result($temp_client_id, $client_id);

        while (mysqli_stmt_fetch($temp_client_id)) 
        {
            $client_id = $client_id;
            echo $client_id;
        }


        //HERE WE ARE SELECTING THE CONTACT ID AND STORE IT IN A VARIABLE
        $select_temp_contact_id = "SELECT contact.contact_id from contact
       where contact.email=?";
        $temp_contact_id = mysqli_prepare($conn, $select_temp_contact_id);
        mysqli_stmt_bind_param($temp_contact_id, "s", $email);
        mysqli_stmt_execute($temp_contact_id);


        $contact_id = 0;
        mysqli_stmt_bind_result($temp_contact_id, $contact_id);


        while (mysqli_stmt_fetch($temp_contact_id)) 
        {
            $contact_id = $contact_id;
            echo $contact_id;
        }

        //HERE WE ARE INSERTING THE CLIENT ID AND CONTAT ID IN THE CLIENT_CONTACT TABLE(LINKING OF OF USERS AND EMAIL)

        $inser_link = "INSERT INTO client_contact(client_id,contact_id,email,client_code) Values(?,?,?,?)";
        $prepare_insert_link = mysqli_prepare($conn, $inser_link);
        mysqli_stmt_bind_param($prepare_insert_link, "ssss", $client_id, $contact_id, $email, $code);
        mysqli_stmt_execute($prepare_insert_link);


        if (!$prepare_insert_link)
         {
            Header("Location: contact.php?status=error_joining");
            Header("Location: contact.php?status=error_joining");


            exit();
        } else {
            Header("Location: client.php?status=client_contact_join");
            Header("Location: contact.php?status=client_contact_join");
            exit();
        }
    }
    #function for getting client's data
    protected function getAllClient()
    {
        #sql query
        $query = "SELECT client.first_name,client.last_name,client.client_code,client_contact.client_id,COUNT(DISTINCT(client_contact.contact_id)) as linked_contacts,client_contact.email
        FROM client
        INNER  JOIN client_contact ON client.client_code=client_contact.client_code
        GROUP BY client.first_name";

        $result = $this->connect()->query($query);


        $result_size = $result->num_rows;


        if ($result_size > 0) 
        {

            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            return $data;
        } else {
            // echo "No client(s) found!";
        }
    }
    #function for getting client's linked data
    protected function getAllLinkedClient()
    {
        #sql query
        $query = "SELECT client.first_name,client.last_name,client.client_code,client_contact.client_id,contact.email,contact.contact_id
        FROM client
        INNER  JOIN client_contact ON client.client_id=client_contact.client_id
        INNER  JOIN contact ON contact.contact_id=client_contact.contact_id
        Order BY client.first_name";

        $result = $this->connect()->query($query);


        $result_size = $result->num_rows;


        if ($result_size > 0) 
        {

            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            return $data;
        } else {
            // echo "No client(s) found!";
        }
    }
    #function for getting client's data
    protected function getAllContact()
    {
        #sql query
        $query = "SELECT client.first_name,client.last_name,client.client_code,contact.email,client_contact.contact_id,
        COUNT(DISTINCT(client_contact.client_id)) as linked_clients
        FROM client
        INNER JOIN client_contact ON 
        client_contact.client_id=client.client_id
        INNER JOIN contact on client_contact.contact_id = 
        contact.contact_id
        GROUP BY client_contact.contact_id
        ORDER by client.first_name";

        $result = $this->connect()->query($query);


        $result_size = $result->num_rows;


        if ($result_size > 0) 
        {

            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            return $data;
        } else {
            // echo "No client(s) found!";
        }
    }
    protected function getAllLinkedContacts()
    {
        #sql query
        $query = "SELECT client.first_name,client.client_id,client.last_name,client.client_code,contact.email
        FROM contact
        INNER  JOIN client_contact ON contact.contact_id=client_contact.contact_id
        INNER  JOIN client ON client.client_id=client_contact.client_id
        Order BY client.first_name";


        $result = $this->connect()->query($query);


        $result_size = $result->num_rows;


        if ($result_size > 0) {

            while ($row = $result->fetch_assoc()) 
            {
                $datas[] = $row;
            }
            return $datas;
        } else {
            // echo "No client(s) found!";
        }
    }
    protected function unlink($id)
    {
        $conn = $this->connect();

        // sql to delete a record
        $sql = "DELETE FROM `client_contact` WHERE client_id = $id";


        if (mysqli_query($conn, $sql)) {
            Header("Location: client.php?status=unlink_client_contact");
            Header("Location: contact.php?status=unlink_client_contact");


            exit();
        } else {
            Header("Location: client.php?status=error_unlinkin");
            Header("Location: contact.php?status=error_unlinkin");
            exit();
        }
    }
}




?>