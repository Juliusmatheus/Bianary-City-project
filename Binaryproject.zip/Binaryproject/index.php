<!DOCTYPE html>
<html lang="en">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Presentation project</title>
    <?php
    
 
$cssFile = "css/style.css";
echo "<link rel='stylesheet' href='" . $cssFile . "'>";


    ?>
    <style>

.flip-box {
  background-color: transparent;
  width: 300px;
  height: 100px;
  float: right;
  justify-content: space-between;
  border: 1px solid #f1f1f1;
  perspective: 1000px; /* Remove this if you don't want the 3D effect */
  margin-right: 40%;
  margin-top: 5%;
  border-radius: 9%;
}


.flip-box h2 {
  text-align:center;
  list-style: none;

}

/* This container is needed to position the front and back side */
.flip-box-inner {
  position: relative;
  width: 70%;
  height: 70%;
  text-align: center;
  transition: transform 0.8s;
  transform-style: preserve-3d;
}

/* Do an horizontal flip when you move the mouse over the flip box container */
.flip-box:hover .flip-box-inner {
  transform: rotateX(180deg);
}

/* Position the front and back side */
.flip-box-front, .flip-box-back {
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden; /* Safari */
  backface-visibility: hidden;
}

/* Style the front side */
.flip-box-front {
  background-color: #bbb;
  color: black;
  border-radius: 9%;
}

/* Style the back side */
.flip-box-back {
  background-color: dodgerblue;
  color: white;
  transform: rotateY(180deg);
  border-radius: 9%;
}

.flip-box:hover .flip-box-inner {
  transform: rotateX(180deg);
}

.flip-box-back {
  transform: rotateX(180deg);
}
    </style>
</head>

<body>
<div class="home" > 

    <div class="flip-box">
        <div class="flip-box-inner">
            <div class="flip-box-front">
                <h2>Client</h2>
                
            </div>
            
            <div class="flip-box-back">
                <h2> View
                <a href="client.php">Client</a></h2>
            </div>
        </div>
    </div>
    <div class="flip-box">
        <div class="flip-box-inner">
            <div class="flip-box-front">
                <h2>Contact</h2>
                
            </div>
            
            <div class="flip-box-back">
            <h2> View
                <a href="contact.php">Contact</a></h2>
            </div>
        </div>
    </div>
    </div>

</body>

</html>